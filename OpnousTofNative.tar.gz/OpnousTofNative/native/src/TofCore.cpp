//
// Created by Junxin Gao on 18-8-1.
// Copyright (c) 2018 ThunderSoft All rights reserved.
//

#include <cstring>
#include <cmath>
#include "TofCore.h"
#include "CpuInlines.h"
#include "depth_table.h"

#define M_PI 3.14159265358979323846

void * mpInRawData = NULL;
bool TofCore::setInputRawData(void *pInRawData) {
    bool ret = true;
    if(ret) {
        if(pInRawData) {
            mpInRawData = pInRawData;
        } else {
            LOGE("Input raw data is null\n");
            ret = false;
        }
    }
    return ret;
}

bool TofCore::process() {
    bool ret = true;
    if(mpInRawData) {
        ret = calculateDepth(mpInRawData, mpCtx->depth);
    } else {
        LOGE("NO input RAW data\n");
        ret = false;
    }
    if(ret && mpCtx->isCorrectOn){
        ret = depthCorrect(mpCtx->depth);
    }
    if(ret) {
        ret = calculatePoints(mpCtx->depth, mpCtx->points);
    } else {
        LOGE("Calculate depth failed\n");
    }
    if(!ret) {
        LOGE("Calculate points failed\n");
    }

    return ret;
}

bool TofCore::getOutputU16DepthData(uint16_t **pOutDepthData) {
    bool ret = true;
    uint16_t * pOutDepth = *pOutDepthData;
    if(pOutDepth != NULL && mpCtx->depth != NULL) {
        memcpy(pOutDepth, mpCtx->depth, mpCtx->width * mpCtx->height * sizeof(uint16_t));
    } else {
        LOGE("OutDepthData is NULL");
    }
    return ret;
}

bool TofCore::getOutputU8RGBADepthData(const uint16_t * pInDepth,
                                       uint8_t ** pOutRGBDepthData,
                                       bool isColor){
    bool ret = true;
    uint8_t * pOutRGBADepth = *pOutRGBDepthData;
    if(!mpCtx->depth) {
        LOGE("Internal DepthData is NULL");
        ret = false;
    }
    if(ret) {
        if(pOutRGBADepth) {
            if(isColor) {
                for(int i = 0; i < mpCtx->height; i++) {
                    for(int j = 0; j < mpCtx->width; j++) {
                        *(pOutRGBADepth + i * mpCtx->width * 4 + j * 4 + 2) = DEPTH_LUT[0][*(pInDepth + i * mpCtx->width +j)];
                        *(pOutRGBADepth + i * mpCtx->width * 4 + j * 4 + 1) = DEPTH_LUT[1][*(pInDepth + i * mpCtx->width +j)];
                        *(pOutRGBADepth + i * mpCtx->width * 4 + j * 4 + 0) = DEPTH_LUT[2][*(pInDepth + i * mpCtx->width +j)];
                    }
                }
            } else {
                for(int i = 0; i < mpCtx->height; i++) {
                    for (int j = 0; j < mpCtx->width; j++) {
                        *(pOutRGBADepth + i * mpCtx->width * 4 + j * 4 + 2) =
                        *(pOutRGBADepth + i * mpCtx->width * 4 + j * 4 + 1) =
                        *(pOutRGBADepth + i * mpCtx->width * 4 + j * 4 + 0) = (uint8_t)*(pInDepth + i * mpCtx->width +j)>>4;
                    }
                }
            }

        } else {
            LOGE("OutRGBADepthData is NULL");
        }
    }

    return ret;
}

bool TofCore::getOutputF32PointsData(float **pOutPointsData) {
    bool ret = true;
    float * pOutPoints = *pOutPointsData;
    if(pOutPoints != NULL && mpCtx->points != NULL) {
        memcpy(pOutPoints, mpCtx->points, mpCtx->width * mpCtx->height * sizeof(float) * 3);
    } else {
        LOGE("OutDepthData is NULL");
        ret = false;
    }
    return ret;
}

bool TofCore::calculateDepth(void *pInRawData, uint16_t *pOutDepth) {
    bool ret = true;

    if(!pInRawData) {
        ret = false;
        LOGE("Input Raw Data NULL\n");
    }

    if(!pOutDepth) {
        ret = false;
        LOGE("Out Depth not allocate memory\n");
    }

    if(ret) {
        switch (mpCtx->rawDepthFmt) {
            case TOF_FMT_MIPI_RAW12:
                ret = mipi12ToDepth((uint8_t*)pInRawData, pOutDepth);
                break;
            case TOF_FMT_RAW16_BIG_ENDIAN:
                ret = bigEndianU16ToDepth((uint16_t*)pInRawData, pOutDepth);
                break;
            default:
                ret = false;
                break;
        }
    }
    return ret;
}

bool TofCore::calculatePoints(uint16_t *pInDepth, float *pOutPoints) {
    bool ret = true;
    double step = 2.0;
    double halfFovHorizontalRad = mpCtx->horizontalFov * M_PI / 360.0;
    double halfFovVerticalRad = mpCtx->verticalFov * M_PI / 360.0;
    double stepHorizontal = step*tan(halfFovHorizontalRad) / ((double)mpCtx->width);
    double stepVertical = step*tan(halfFovVerticalRad) / ((double)mpCtx->height);
    double startHorizontal = -tan(halfFovHorizontalRad);
    double startVertical = tan(halfFovVerticalRad);
    int currentPixelInd = 0;
    float depthToPosMatX = 0, depthToPosMatY = 0;

    if(!pInDepth) {
        ret = false;
        LOGE("Input depth data is null\n");
    }

    if(!pOutPoints) {
        ret = false;
        LOGE("Out points not allocate memory\n");
    }

    if(ret) {
        for (int i = CROPCELL; i<mpCtx->height - CROPCELL; i++) {
            for (int j = CROPCELL; j<mpCtx->width - CROPCELL; j++) {
                int index = i * mpCtx->width + j;

                depthToPosMatX = (float)(startHorizontal + ((float)j)*stepHorizontal);
                depthToPosMatY = (float)(startVertical - ((float)i)*stepVertical);

                *(pOutPoints + index*3 + 2) = (float)(*(pInDepth + index)/1000.0/5.0f);
                *(pOutPoints + index*3 + 1) = *(pOutPoints + index*3 + 2) * depthToPosMatY;
                *(pOutPoints + index*3 + 0) = *(pOutPoints + index*3 + 2) * depthToPosMatX;
            }
        }
    }
    return ret;
}

bool TofCore::mipi12ToDepth(uint8_t *pInRawData,
                            uint16_t *pOutData) {
    bool ret = true;
    uint8_t * pInRawU8Data = NULL;
    uint16_t * pOutDepth = NULL;
    uint16_t P11;
    uint16_t P22;
    uint16_t P33;
    uint16_t Q11;
    uint16_t Q22;
    uint16_t Q33;
    uint16_t Q1;
    uint16_t Q2;
    uint16_t Q3;
    float raw_distance;
    if(ret) {
        if(pInRawData) {
            pInRawU8Data = pInRawData;
        } else {
            ret = false;
        }
    }
    if(ret) {
        if(pOutData) {
            pOutDepth = pOutData;
        } else {
            ret = false;
        }
    }
    if(ret) {
        if(!mpCtx->rawARGBData) {
            ret = false;
            LOGE("Raw rgba data is not alloc memory");
        }
    }
    if(ret) {
        if(!mpCtx->IRARGBData) {
            ret = false;
            LOGE("IR rgba data is not alloc memory");
        }
    }
    if(ret) {
        for(int i = 0; i < mpCtx->height; i++) {
            for(int j = 0; j < mpCtx->width / 2; j++) {
                Q1 = *(pInRawU8Data + (j * 3 + 0) + mpCtx->rawRowStride * (i * 3 + 0));
                Q2 = *(pInRawU8Data + (j * 3 + 1) + mpCtx->rawRowStride * (i * 3 + 0));
                Q3 = *(pInRawU8Data + (j * 3 + 2) + mpCtx->rawRowStride * (i * 3 + 0));
                Q11 = 4095 - (((Q1 & 0x00FF) << 4) | ((Q3 & 0x00F0) >> 4));
                P11 = 4095 - (((Q2 & 0x00FF) << 4) | (Q3 & 0x000F));
                *(mpCtx->rawARGBData + (j * 2 * 4 + 0) + mpCtx->width * (i * 3 + 0) * 4) =
                *(mpCtx->rawARGBData + (j * 2 * 4 + 1) + mpCtx->width * (i * 3 + 0) * 4) =
                *(mpCtx->rawARGBData + (j * 2 * 4 + 2) + mpCtx->width * (i * 3 + 0) * 4) = (uint8_t)(Q1);
                *(mpCtx->rawARGBData + (j * 2 * 4 + 4) + mpCtx->width * (i * 3 + 0) * 4) =
                *(mpCtx->rawARGBData + (j * 2 * 4 + 5) + mpCtx->width * (i * 3 + 0) * 4) =
                *(mpCtx->rawARGBData + (j * 2 * 4 + 6) + mpCtx->width * (i * 3 + 0) * 4) = (uint8_t)(Q2);
                Q1 = *(pInRawU8Data + (j * 3 + 0) + mpCtx->rawRowStride * (i * 3 + 1));
                    Q2 = *(pInRawU8Data + (j * 3 + 1) + mpCtx->rawRowStride * (i * 3 + 1));
                Q3 = *(pInRawU8Data + (j * 3 + 2) + mpCtx->rawRowStride * (i * 3 + 1));
                Q22 = 4095 - (((Q1 & 0x00FF) << 4) | ((Q3 & 0x00F0) >> 4));
                P22 = 4095 - (((Q2 & 0x00FF) << 4) | (Q3 & 0x000F));
                *(mpCtx->IRARGBData + (j * 2 * 4 + 0) + mpCtx->width * i * 4) =
                *(mpCtx->IRARGBData + (j * 2 * 4 + 1) + mpCtx->width * i * 4) =
                *(mpCtx->IRARGBData + (j * 2 * 4 + 2) + mpCtx->width * i * 4) =
                *(mpCtx->rawARGBData + (j * 2 * 4 + 0) + mpCtx->width * (i * 3 + 1) * 4) =
                *(mpCtx->rawARGBData + (j * 2 * 4 + 1) + mpCtx->width * (i * 3 + 1) * 4) =
                *(mpCtx->rawARGBData + (j * 2 * 4 + 2) + mpCtx->width * (i * 3 + 1) * 4) = (uint8_t)(Q1);
                *(mpCtx->IRARGBData + (j * 2 * 4 + 4) + mpCtx->width * i * 4) =
                *(mpCtx->IRARGBData + (j * 2 * 4 + 5) + mpCtx->width * i * 4) =
                *(mpCtx->IRARGBData + (j * 2 * 4 + 6) + mpCtx->width * i * 4) =
                *(mpCtx->rawARGBData + (j * 2 * 4 + 4) + mpCtx->width * (i * 3 + 1) * 4) =
                *(mpCtx->rawARGBData + (j * 2 * 4 + 5) + mpCtx->width * (i * 3 + 1) * 4) =
                *(mpCtx->rawARGBData + (j * 2 * 4 + 6) + mpCtx->width * (i * 3 + 1) * 4) = (uint8_t)(Q2);
                Q1 = *(pInRawU8Data + (j * 3 + 0) + mpCtx->rawRowStride * (i * 3 + 2));
                Q2 = *(pInRawU8Data + (j * 3 + 1) + mpCtx->rawRowStride * (i * 3 + 2));
                Q3 = *(pInRawU8Data + (j * 3 + 2) + mpCtx->rawRowStride * (i * 3 + 2));
                Q33 = 4095 - (((Q1 & 0x00FF) << 4) | ((Q3 & 0x00F0) >> 4));
                P33 = 4095 - (((Q2 & 0x00FF) << 4) | (Q3 & 0x000F));
                *(mpCtx->rawARGBData + (j * 2 * 4 + 0) + mpCtx->width * (i * 3 + 2) * 4) =
                *(mpCtx->rawARGBData + (j * 2 * 4 + 1) + mpCtx->width * (i * 3 + 2) * 4) =
                *(mpCtx->rawARGBData + (j * 2 * 4 + 2) + mpCtx->width * (i * 3 + 2) * 4) = (uint8_t)(Q1);
                *(mpCtx->rawARGBData + (j * 2 * 4 + 4) + mpCtx->width * (i * 3 + 2) * 4) =
                *(mpCtx->rawARGBData + (j * 2 * 4 + 5) + mpCtx->width * (i * 3 + 2) * 4) =
                *(mpCtx->rawARGBData + (j * 2 * 4 + 6) + mpCtx->width * (i * 3 + 2) * 4) = (uint8_t)(Q2);
                raw_distance = float(1000 * 0.5 * C_LIGHT_SPEED * T0_LIGHT_PLUSE * ((Q33 - Q11) *1.0 / (Q22 + Q33 - 2 * Q11)));
                raw_distance = clamp(raw_distance, SMIN, SMAX);
                *(pOutDepth + (j * 2 + 0) + i * mpCtx->width) = (uint16_t)raw_distance;
                raw_distance = float(1000 * 0.5 * C_LIGHT_SPEED * T0_LIGHT_PLUSE * ((P33 - P11) *1.0 / (P22 + P33 - 2 * P11)));
                raw_distance = clamp(raw_distance, SMIN, SMAX);
                *(pOutDepth + (j * 2 + 1) + i * mpCtx->width) = (uint16_t)raw_distance;
            }
        }
    }
    if (ret) {
        int32_t g1Sum = 0;
        int32_t g2Sum = 0;
        int32_t g3Sum = 0;
        int32_t g11 = 0;
        int32_t g22 = 0;
        for (int i = 0; i < mpCtx->width / 2; i++) {
            Q1 = *(pInRawU8Data + (mpCtx->rawRowStride * (mpCtx->rawHeight - 3)) + i * 3 + 0);
            Q2 = *(pInRawU8Data + (mpCtx->rawRowStride * (mpCtx->rawHeight - 3)) + i * 3 + 1);
            Q3 = *(pInRawU8Data + (mpCtx->rawRowStride * (mpCtx->rawHeight - 3)) + i * 3 + 2);
            g11 = (((Q1 & 0x00FF) << 4) | ((Q3 & 0x00F0) >> 4));
            g22 = (((Q2 & 0x00FF) << 4) | (Q3 & 0x000F));
            g1Sum += g11;
            g1Sum += g22;
            Q1 = *(pInRawU8Data + (mpCtx->rawRowStride * (mpCtx->rawHeight - 2)) + i * 3 + 0);
            Q2 = *(pInRawU8Data + (mpCtx->rawRowStride * (mpCtx->rawHeight - 2)) + i * 3 + 1);
            Q3 = *(pInRawU8Data + (mpCtx->rawRowStride * (mpCtx->rawHeight - 2)) + i * 3 + 2);
            g11 = (((Q1 & 0x00FF) << 4) | ((Q3 & 0x00F0) >> 4));
            g22 = (((Q2 & 0x00FF) << 4) | (Q3 & 0x000F));
            g2Sum += g11;
            g2Sum += g22;
            Q1 = *(pInRawU8Data + (mpCtx->rawRowStride * (mpCtx->rawHeight - 1)) + i * 3 + 0);
            Q2 = *(pInRawU8Data + (mpCtx->rawRowStride * (mpCtx->rawHeight - 1)) + i * 3 + 1);
            Q3 = *(pInRawU8Data + (mpCtx->rawRowStride * (mpCtx->rawHeight - 1)) + i * 3 + 2);
            g11 = (((Q1 & 0x00FF) << 4) | ((Q3 & 0x00F0) >> 4));
            g22 = (((Q2 & 0x00FF) << 4) | (Q3 & 0x000F));
            g3Sum += g11;
            g3Sum += g22;
        }
        mpCtx->tempG1 = g1Sum / mpCtx->width;
        mpCtx->tempG2 = g2Sum / mpCtx->width;
        mpCtx->tempG3 = g3Sum / mpCtx->width;
    }
    return ret;
}

bool TofCore::bigEndianU16ToDepth(uint16_t *pInRawData, uint16_t *pOutData) {
    bool ret = true;
    uint16_t Q11;
    uint16_t Q22;
    uint16_t Q33;
    uint16_t Q1;
    uint16_t Q2;
    uint16_t Q3;
    float raw_distance;
    uint16_t * pOutDepth = NULL;
    if(ret) {
        if(!pInRawData) {
            ret = false;
        }
    }
    if(ret) {
        if(pOutData) {
            pOutDepth = pOutData;
        } else {
            ret = false;
        }
    }
    if(ret) {
        if(!mpCtx->rawARGBData) {
            ret = false;
            LOGE("Raw rgba data is not alloc memory");
        }
    }
    if(ret) {
        if(!mpCtx->IRARGBData) {
            ret = false;
            LOGE("IR rgba data is not alloc memory");
        }
    }
    if(ret) {
        for (int i = 0; i < mpCtx->height; ++i) {
            for (int j = 0; j < mpCtx->width; ++j) {
                Q1 = *(pInRawData + j + mpCtx->width * (i * 3 + 0));  // Q1
                Q2 = *(pInRawData + j + mpCtx->width * (i * 3 + 1));  // Q2
                Q3 = *(pInRawData + j + mpCtx->width * (i * 3 + 2));  // Q3

                Q11 = 4095 - ((Q1 & 0xF000) >> 12 | (Q1 & 0x00FF) << 4);
                Q22 = 4095 - ((Q2 & 0xF000) >> 12 | (Q2 & 0x00FF) << 4);
                Q33 = 4095 - ((Q3 & 0xF000) >> 12 | (Q3 & 0x00FF) << 4);

                *(mpCtx->IRARGBData + (j * 4 + 0) + mpCtx->width * i * 4) =
                *(mpCtx->IRARGBData + (j * 4 + 1) + mpCtx->width * i * 4) =
                *(mpCtx->IRARGBData + (j * 4 + 2) + mpCtx->width * i * 4) =
                *(mpCtx->rawARGBData + (j * 4 + 0) + mpCtx->width * (i * 3 + 0) * 4) =
                *(mpCtx->rawARGBData + (j * 4 + 1) + mpCtx->width * (i * 3 + 0) * 4) =
                *(mpCtx->rawARGBData + (j * 4 + 2) + mpCtx->width * (i * 3 + 0) * 4) = (uint8_t)(Q1 & 0x00FF);
                *(mpCtx->rawARGBData + (j * 4 + 0) + mpCtx->width * (i * 3 + 1) * 4) =
                *(mpCtx->rawARGBData + (j * 4 + 1) + mpCtx->width * (i * 3 + 1) * 4) =
                *(mpCtx->rawARGBData + (j * 4 + 2) + mpCtx->width * (i * 3 + 1) * 4) = (uint8_t)(Q2 & 0x00FF);
                *(mpCtx->rawARGBData + (j * 4 + 0) + mpCtx->width * (i * 3 + 2) * 4) =
                *(mpCtx->rawARGBData + (j * 4 + 1) + mpCtx->width * (i * 3 + 2) * 4) =
                *(mpCtx->rawARGBData + (j * 4 + 2) + mpCtx->width * (i * 3 + 2) * 4) = (uint8_t)(Q3 & 0x00FF);

                raw_distance = float(1000 * 0.5 * C_LIGHT_SPEED * T0_LIGHT_PLUSE * ((Q33 - Q11) *1.0 / (Q22 + Q33 - 2 * Q11)));
                raw_distance = clamp(raw_distance, SMIN, SMAX);
                *(pOutDepth + j + i * mpCtx->width) = (uint16_t)raw_distance;
            }
        }
    }
    return ret;
}

bool TofCore::setTemperatureOffset(uint32_t offset) {
    bool ret = true;
    if(ret) {
        mpCtx->tempOffset = offset;
    }
    return ret;
}

bool TofCore::littleEndianU16ToDepth(uint16_t *pInRawData, uint16_t *pOutData) {
    bool ret = true;
    uint16_t Q11;
    uint16_t Q22;
    uint16_t Q33;
    uint16_t Q1;
    uint16_t Q2;
    uint16_t Q3;
    float raw_distance;
    uint16_t * pOutDepth = NULL;
    if(ret) {
        if(!pInRawData) {
            ret = false;
        }
    }
    if(ret) {
        if(pOutData) {
            pOutDepth = pOutData;
        } else {
            ret = false;
        }
    }
#if 0
    if(ret) {
        for (int i = 0; i < mpCtx->height; ++i) {
            for (int j = 0; j < mpCtx->width; ++j) {
                Q1 = *(pInRawData + j + mpCtx->width * (i * 3 + 0));  // Q1
                Q2 = *(pInRawData + j + mpCtx->width * (i * 3 + 1));  // Q2
                Q3 = *(pInRawData + j + mpCtx->width * (i * 3 + 2));  // Q3

                Q11 = 4095 - ((Q1 & 0xF000) >> 12 | (Q1 & 0x00FF) << 4);
                Q22 = 4095 - ((Q2 & 0xF000) >> 12 | (Q2 & 0x00FF) << 4);
                Q33 = 4095 - ((Q3 & 0xF000) >> 12 | (Q3 & 0x00FF) << 4);

                raw_distance = float(1000 * 0.5 * C_LIGHT_SPEED * T0_LIGHT_PLUSE * ((Q33 - Q11) *1.0 / (Q22 + Q33 - 2 * Q11)));
                //raw_distance -= fixed_system_offset;
                raw_distance = clamp(raw_distance, SMIN, SMAX);
                *(pOutDepth + j + i * mpCtx->width) = (uint16_t)raw_distance;
                //if (i < 32 && j < 2) {
                //LOGD("rect[%dx%d], depthdata[%d]: %d", tof_width, tof_height, j+i*tof_width, dst[j+i*tof_width]);
                //}
            }
        }
    }
#endif
    return false;
}

bool TofCore::getOutputU8RGBAIRData(uint8_t **pOutU8RGBAIR) {
    bool ret = true;
    uint8_t * pOutU8IR = *pOutU8RGBAIR;
    if(ret) {
        if(!pOutU8IR) {
            ret = false;
            LOGE("In depth buffer is null");
        }
    }
    if(ret) {
        if(!mpCtx->IRARGBData) {
            ret = false;
            LOGE("Tof internal ir rgba data is null");
        }
    }
    if(ret) {
        memcpy(pOutU8IR, mpCtx->IRARGBData, mpCtx->width * mpCtx->height * sizeof(uint8_t) * 4);
    }
    return ret;
}

bool TofCore::getOutputU8RGBARawDepthData(uint8_t **pU8RGBARawDepth) {
    bool ret = true;
    uint8_t * pOutU8RawDepth = *pU8RGBARawDepth;
    if(ret) {
        if(!pOutU8RawDepth) {
            ret = false;
            LOGE("In depth buffer is null");
        }
    }
    if(ret) {
        if(!mpCtx->rawARGBData) {
            ret = false;
            LOGE("Tof internal raw rgba data is null");
        }
    }
    if(ret) {
        memcpy(pOutU8RawDepth, mpCtx->rawARGBData, mpCtx->width * mpCtx->rawHeight * sizeof(uint8_t) * 4);
    }
    return ret;
}

int TofCore::getCroodDepthValue(const uint16_t *calcData, int x, int y) {
    int sum = 0;
    int validCnt = 0;
    int calR = 10;
    int tmp = 0;
    x--;
    y--;
    if (x < 0 || y < 0 || x >= mpCtx->width || y >= mpCtx->height)
        return -1;
    if (x - calR <= 0 || x + calR >= mpCtx->width || y - calR <= 0 || y + calR >= mpCtx->height)
        return *(calcData + y * mpCtx->width + x);
    for (int i = x - calR; i <= x + calR; i++) {
        for (int j = y - calR; j <= y + calR; j++) {
            tmp = *(calcData + j * mpCtx->width + i);
            if (tmp > 16 && tmp < MAXDEPTH) {
                validCnt++;
                sum += tmp;
            }
        }
    }
    if (validCnt == 0)
        return *(calcData + y * mpCtx->width + x);
    else
        return sum / validCnt;
}

int TofCore::getTemperatureValue(LINE_G_MODE gMode) {
    int temperature;
    switch (gMode) {
        case LINE_G1:
            temperature = mpCtx->tempG1;
            break;
        case LINE_G2:
            temperature = mpCtx->tempG2;
            break;
        case LINE_G3:
            temperature = mpCtx->tempG3;
            break;
        case LINE_G_DEFAULT:
            temperature = (mpCtx->tempG2 + mpCtx->tempG3 + mpCtx->tempG1) / 3;
            break;
        default:
            temperature = (mpCtx->tempG2 + mpCtx->tempG3 + mpCtx->tempG1) / 3;
            break;
    }
    temperature -= mpCtx->tempOffset;
    return temperature;
}

bool TofCore::depthCorrect(uint16_t* pInDepth) {
    bool ret = true;
    long double tmp;
    long double sum;
    if(pInDepth == NULL) {
        LOGE("pInDepth is NULL \n");
        ret = false;
        return false;
    }

    double* pCoefTable = (double*)mpCtx->coefTable;
    for (int i = 0; i < mpCtx->height; i++) {
        for (int j = 0; j < mpCtx->width; j++) {
            tmp = (long double)*(pInDepth + i*mpCtx->width + j) / SMAX;
            tmp = (
                  pow(tmp, 4) * *(pCoefTable + 248*mpCtx->width + 0) +
                  pow(tmp, 3) * *(pCoefTable + 248*mpCtx->width + 1) +
                  pow(tmp, 2) * *(pCoefTable + 248*mpCtx->width + 2) +
                  pow(tmp, 1) * *(pCoefTable + 248*mpCtx->width + 3) +
                  *(pCoefTable + 248*mpCtx->width + 4)
                );
            sum = tmp * *(pCoefTable  + i*mpCtx->width+j) + *(pCoefTable + mpCtx->width * (249+i)+j);
            uint16_t ttt = clamp((uint16_t)(sum), 0, MAXDEPTH);
            *(pInDepth + i*mpCtx->width + j) = ttt; 
        }
    }
    return ret;
}

bool TofCore::setHorizontalFov(int horizontalFov) {
    mpCtx->horizontalFov = horizontalFov;
    return true;
}

bool TofCore::setVerticalFov(int verticalFov) {
    mpCtx->verticalFov = verticalFov;
    return true;
}

bool TofCore::setDepthCorrectOn(bool isCorrectOn){
    mpCtx->isCorrectOn = isCorrectOn;
    return true;
}
