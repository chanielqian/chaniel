//
// Created by Junxin Gao on 18-8-1.
// Copyright (c) 2018 ThunderSoft All rights reserved.
//

#include <TofCore.h>
#include "com_thundersoft_TSJniUtil.h"
#include <android/bitmap.h>

TofCore* mpTofCore = NULL;

char *jstringToChar(JNIEnv *env, jstring jstr) {
   char *rtn = NULL;
   jclass clsstring = env->FindClass("java/lang/String");
   jstring strencode = env->NewStringUTF("GB2312");
   jmethodID mid = env->GetMethodID(clsstring, "getBytes", "(Ljava/lang/String;)[B");
   jbyteArray barr = (jbyteArray) env->CallObjectMethod(jstr, mid, strencode);
   jsize alen = env->GetArrayLength(barr);
   jbyte *ba = env->GetByteArrayElements(barr, JNI_FALSE);
   if (alen > 0) {
       rtn = (char *) malloc(alen + 1);
       memcpy(rtn, ba, alen);
       rtn[alen] = 0;
   }
   env->ReleaseByteArrayElements(barr, ba, 0);
   return rtn;
}

/*
 * Class:     com_thundersoft_TSJniUtil
 * Method:    opnousTofInit
 * Signature: (II)I
 */
JNIEXPORT jint JNICALL Java_com_thundersoft_TSJniUtil_opnousTofInit(JNIEnv *jEnv,
                                                                    jclass jClz,
                                                                    jint width,
                                                                    jint height,
                                                                    jint rowStride,
                                                                    jfloat pixStride,
                                                                    jstring path) {
    jint ret = 0;
    char* coefPath = jstringToChar(jEnv, path);
    mpTofCore = TofCore::createInstance(width, height, rowStride, pixStride, TOF_FMT_MIPI_RAW12, coefPath);
    return ret;
}

/*
 * Class:     com_thundersoft_TSJniUtil
 * Method:    opnousTofProcess
 * Signature: (Ljava/nio/ByteBuffer;)I
 */
JNIEXPORT jint JNICALL Java_com_thundersoft_TSJniUtil_opnousTofProccess(JNIEnv *jEnv,
                                                                        jclass jClz,
                                                                        jobject inRawBuffer) {
    jint ret = 0;
    void* pRawData = NULL;
    if(!mpTofCore) {
        ret = -1;
        LOGE("TofCore context is null");
    }
    if(ret == 0) {
        pRawData = jEnv->GetDirectBufferAddress(inRawBuffer);
        if(pRawData) {
            if(!mpTofCore->setInputRawData(pRawData)) {
                ret = -1;
                LOGE("Tof library set raw data failed");
            }
        } else {
            ret = -1;
            LOGE("Input raw data is NULL");
        }
    }
    if(ret == 0) {
        if(!mpTofCore->process()) {
            ret = -1;
            LOGE("Tof library process failed");
        }
    }
    return ret;
}

JNIEXPORT jint JNICALL Java_com_thundersoft_TSJniUtil_opnousTofSetDepthCorrectOn(JNIEnv *jEnv,
                                                                        jclass jClz,
                                                                        jint isCorrectOn) {

     jint ret = 0;
     mpTofCore->setDepthCorrectOn(isCorrectOn == 1?true:false);
     return ret;                                                      
}

/*
 * Class:     com_thundersoft_TSJniUtil
 * Method:    opnousTofGetDepthBuffer
 * Signature: (Ljava/nio/ByteBuffer;)I
 */
JNIEXPORT jint JNICALL Java_com_thundersoft_TSJniUtil_opnousTofGetDepthBuffer(JNIEnv *jEnv,
                                                                              jclass jClz,
                                                                              jobject outDepthBuffer) {
    jint ret = 0;
    void* pOutDepthData = NULL;
    if(!mpTofCore) {
        ret = -1;
        LOGE("TofCore context is null");
    }
    if(ret == 0) {
        pOutDepthData = jEnv->GetDirectBufferAddress(outDepthBuffer);
    }
    if(ret == 0) {
        if(pOutDepthData) {
            uint16_t * pOutU16Depth = (uint16_t*)pOutDepthData;
            if(!mpTofCore->getOutputU16DepthData(&pOutU16Depth)) {
                ret = -1;
                LOGE("Get out depth data failed");
            }
        } else {
            ret = -1;
            LOGE("Out depth data is not allocate direct ByteBuffer");
        }
    }
    return ret;
}

/*
 * Class:     com_thundersoft_TSJniUtil
 * Method:    opnousTofGetPointsBuffer
 * Signature: (Ljava/nio/ByteBuffer;)I
 */
JNIEXPORT jint JNICALL Java_com_thundersoft_TSJniUtil_opnousTofGetPointsBuffer(JNIEnv *jEnv,
                                                                               jclass jClz,
                                                                               jobject outPointsBuffer) {
    jint ret = 0;
    void* pOutPointsData = NULL;
    if(!mpTofCore) {
        ret = -1;
        LOGE("TofCore context is null");
    }
    if(ret == 0) {
        pOutPointsData = jEnv->GetDirectBufferAddress(outPointsBuffer);
    }
    if(ret == 0) {
        if(pOutPointsData) {
            float * pOutFloatPoints = (float*)pOutPointsData;
            if(!mpTofCore->getOutputF32PointsData(&pOutFloatPoints)) {
                ret = -1;
                LOGE("Get out points data failed");
            }
        } else {
            ret = -1;
            LOGE("Out points data is not allocate direct ByteBuffer");
        }
    }
    return ret;
}

/*
 * Class:     com_thundersoft_TSJniUtil
 * Method:    opnousTofTerm
 * Signature: ()I
 */
JNIEXPORT jint JNICALL Java_com_thundersoft_TSJniUtil_opnousTofTerm(JNIEnv *jEnv,
                                                                    jclass jClz) {
    jint ret = 0;
    if(!mpTofCore) {
        ret = -1;
        LOGE("TofCore context is already delete");
    }
    if(ret == 0) {
        delete mpTofCore;
    }
    return ret;
}

/*
 * Class:     com_thundersoft_TSJniUtil
 * Method:    opnousTofGetDepthBitmap
 * Signature: (Landroid/graphics/Bitmap;)I
 */
JNIEXPORT jint JNICALL Java_com_thundersoft_TSJniUtil_opnousTofGetDepthBitmap(JNIEnv *jEnv,
                                                                              jclass jClz,
                                                                              jobject inDepth,
                                                                              jobject outBitmap,
                                                                              jint isColor) {
                                                                                LOGE("%s E", __func__);
    jint ret = 0;
    void* dst = NULL;
    void* pInDepth = NULL;
    if(!mpTofCore) {
        ret = -1;
        LOGE("TofCore context is null");
    }
    if(ret == 0) {
        pInDepth = jEnv->GetDirectBufferAddress(inDepth);
        if(!pInDepth) {
            ret = -1;
        }
    }
    if(ret == 0) {
        AndroidBitmap_lockPixels(jEnv, outBitmap, &dst);
        uint8_t *pOutBitmap =(uint8_t*)dst;
        if(pOutBitmap) {
            const uint16_t *pInDepthData = (const uint16_t*)pInDepth;
            mpTofCore->getOutputU8RGBADepthData(pInDepthData, &pOutBitmap, isColor);
        } else {
            ret = -1;
        }
        AndroidBitmap_unlockPixels(jEnv, outBitmap);
    }
    LOGE("%s X", __func__);
    return ret;
}

/*
 * Class:     com_thundersoft_TSJniUtil
 * Method:    opnousTofGetRawBitmap
 * Signature: (Landroid/graphics/Bitmap;)I
 */
JNIEXPORT jint JNICALL Java_com_thundersoft_TSJniUtil_opnousTofGetRawBitmap(JNIEnv *jEnv,
                                                                            jclass jClz,
                                                                            jobject outBitmap) {
    jint ret = 0;
    void* dst = NULL;
    if(!mpTofCore) {
        ret = -1;
        LOGE("TofCore context is null");
    }
    if(ret == 0) {
        AndroidBitmap_lockPixels(jEnv, outBitmap, &dst);
        uint8_t *pOutBitmap =(uint8_t*)dst;
        if(dst) {
            mpTofCore->getOutputU8RGBARawDepthData(&pOutBitmap);
        } else {
            ret = -1;
        }
        AndroidBitmap_unlockPixels(jEnv, outBitmap);
    }
    return ret;
}

/*
 * Class:     com_thundersoft_TSJniUtil
 * Method:    opnousTofGetIRBitmap
 * Signature: (Landroid/graphics/Bitmap;)I
 */
JNIEXPORT jint JNICALL Java_com_thundersoft_TSJniUtil_opnousTofGetIRBitmap(JNIEnv *jEnv,
                                                                           jclass jClz,
                                                                           jobject outBitmap) {
    jint ret = 0;
    void* dst = NULL;
    if(!mpTofCore) {
        ret = -1;
        LOGE("TofCore context is null");
    }
    if(ret == 0) {
        AndroidBitmap_lockPixels(jEnv, outBitmap, &dst);
        uint8_t *pOutBitmap =(uint8_t*)dst;
        if(dst) {
            mpTofCore->getOutputU8RGBAIRData(&pOutBitmap);
        } else {
            ret = -1;
        }
        AndroidBitmap_unlockPixels(jEnv, outBitmap);
    }
    return ret;
}

/*
 * Class:     com_thundersoft_TSJniUtil
 * Method:    opnousTofGetCroodDepthValue
 * Signature: (Ljava/nio/ByteBuffer;)I
 */
JNIEXPORT jint JNICALL Java_com_thundersoft_TSJniUtil_opnousTofGetCroodDepthValue
        (JNIEnv *jEnv, jclass jClz, jobject inDepth, jint x, jint y) {
    jint ret = 0;
    void* pInDepth = NULL;
    if(!mpTofCore) {
        ret = -1;
        LOGE("TofCore context is null");
    }
    if(ret == 0) {
        pInDepth = jEnv->GetDirectBufferAddress(inDepth);
        if(!pInDepth) {
            ret = -1;
        }
    }
    if(ret == 0) {
        ret = mpTofCore->getCroodDepthValue((uint16_t*)pInDepth, x, y);
    }
    return ret;
}

/*
 * Class:     com_thundersoft_TSJniUtil
 * Method:    opnousTofGetTemperature
 * Signature: (IIIF)I
 */
JNIEXPORT jint JNICALL Java_com_thundersoft_TSJniUtil_opnousTofGetTemperature
        (JNIEnv *, jclass, jint gMode, jint offset) {
    mpTofCore->setTemperatureOffset(offset);
    return mpTofCore->getTemperatureValue((LINE_G_MODE)gMode);
}

JNIEXPORT jint Java_com_thundersoft_TSJniUtil_opnousTofSetHorizontalFov
        (JNIEnv *, jclass, jint horizontalFov) {
    jint ret = 0;
    mpTofCore->setHorizontalFov(horizontalFov);
    return ret;
}

JNIEXPORT jint Java_com_thundersoft_TSJniUtil_opnousTofSetVerticalFov
        (JNIEnv *, jclass, jint verticalFov) {
    jint ret = 0;
    mpTofCore->setVerticalFov(verticalFov);
    return ret;
}
