//
// Created by Junxin Gao on 18-8-9.
// Copyright (c) 2018 ThunderSoft All rights reserved.
//

#ifndef PROJECT_CPUINLINES_H
#define PROJECT_CPUINLINES_H
static inline float clamp(float amount, float low, float high) {
    return amount < low ? low : (amount > high ? high : amount);
}
static inline uint16_t clamp(uint16_t amount, uint16_t low, uint16_t high) {
    return amount < low ? low : (amount > high ? high : amount);
}
#endif //PROJECT_CPUINLINES_H