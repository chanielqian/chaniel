//
// Created by Junxin Gao on 18-8-1.
// Copyright (c) 2018 ThunderSoft All rights reserved.
//

#ifndef PROJECT_TOFCORE_H
#define PROJECT_TOFCORE_H

#include <stdint.h>
#include <cstdlib>
#include <cstdio>
#include <pthread.h>

#ifdef __ANDROID__
#include <android/log.h>
#define LOGD(...) __android_log_print(ANDROID_LOG_DEBUG, "TSNativeLib", __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, "TSNativeLib", __VA_ARGS__)
#else
#include <stdio.h>
#define LOGD(...) fprintf(stdout, __VA_ARGS__)
#define LOGE(...) fprintf(stderr, __VA_ARGS__)
#endif

enum TOF_FMT{
    TOF_FMT_MIPI_RAW12,
    TOF_FMT_RAW16_BIG_ENDIAN,
    TOF_FMT_RAW16_LITTLE_ENDIAN,
};

enum LINE_G_MODE{
    LINE_G1,
    LINE_G2,
    LINE_G3,
    LINE_G_DEFAULT
};

struct context {
    uint32_t width;
    uint32_t height;
    uint32_t rawRowStride;
    uint32_t rawHeight;
    float rawPixStride;
    uint16_t *depth;
    float *points;
    uint8_t *IRARGBData;
    uint8_t *rawARGBData;
    int32_t tempG1;
    int32_t tempG2;
    int32_t tempG3;
    TOF_FMT rawDepthFmt;
    int32_t tempOffset;
    void* coefTable;
    bool isCorrectOn;
    int verticalFov;
    int horizontalFov;
    pthread_mutex_t mutex;
};

static void read_csv(int row, int col, char *filename, double **in){
	FILE *file;
	file = fopen(filename, "r");
    double* data = *in;
	int i = 0;
    char line[4098];
	while (fgets(line, 4098, file) && (i < row)){
        char* tmp = strdup(line);
	    int j = 0;
	    const char* tok;
	    for (tok = strtok(line, ","); tok && *tok; j++, tok = strtok(NULL, ",")) {
			*(data + i*col + j) = atof(tok);
	    }
        free(tmp);
        i++;
    }
}

class TofCore {
public:
    ~TofCore() {
        if(mpCtx->depth) {
            free(mpCtx->depth);
            mpCtx->depth = NULL;
        }
        if(mpCtx->points) {
            free(mpCtx->points);
            mpCtx->points = NULL;
        }
        if(mpCtx->IRARGBData) {
            free(mpCtx->IRARGBData);
            mpCtx->IRARGBData = NULL;
        }
        if(mpCtx->rawARGBData) {
            free(mpCtx->rawARGBData);
            mpCtx->rawARGBData = NULL;
        }
        if(mpCtx->coefTable) {
            free(mpCtx->coefTable);
            mpCtx->coefTable = NULL;
        }
        if(mpCtx) {
            free(mpCtx);
            mpCtx = NULL;
        }
    }
    bool setInputRawData(void* pInRawData);
    bool process();
    bool getOutputU16DepthData(uint16_t** pOutDepthData);
    bool getOutputU8RGBADepthData(const uint16_t * pInDepth,
                                  uint8_t ** pOutRGBDepthData,
                                  bool isColor);
    bool getOutputF32PointsData(float** pOutPointsData);
    bool getOutputU8RGBAIRData(uint8_t ** pOutU8RGBAIR);
    bool getOutputU8RGBARawDepthData(uint8_t ** pU8RGBARawDepth);
    int getCroodDepthValue(const uint16_t *calcData, int x, int y);
    bool setTemperatureOffset(uint32_t offset);
    bool setDepthCorrectOn(bool isCorrectOn);
    bool setVerticalFov(int verticalFov);
    bool setHorizontalFov(int horizontalFov);
    int getTemperatureValue(LINE_G_MODE gMode);
    static TofCore* createInstance(uint32_t width,
                                   uint32_t height,
                                   uint32_t rowStride,
                                   float pixStride,
                                   TOF_FMT rawFormat,
                                   char* coefPath) {
        return new TofCore(width, height, rowStride,  pixStride, rawFormat, coefPath);
    }

protected:
    TofCore(uint32_t width,
            uint32_t height,
            uint32_t rowStride,
            float pixStride,
            TOF_FMT rawFormat,
            char* coefPath) {
        mpCtx = (struct context*)malloc(sizeof(struct context));
        if(mpCtx) {
            mpCtx->width = width;
            mpCtx->rawHeight = height * 3;
            mpCtx->height = height;
            mpCtx->rawDepthFmt = rawFormat;
            mpCtx->rawPixStride = pixStride;
            mpCtx->rawRowStride = rowStride;
            mpCtx->depth = (uint16_t*)malloc(mpCtx->width * mpCtx->height * sizeof(uint16_t));
            mpCtx->points = (float*)malloc(mpCtx->width * mpCtx->height * sizeof(float) * 3);
            mpCtx->rawARGBData = (uint8_t *)malloc(mpCtx->width * mpCtx->rawHeight * sizeof(uint8_t) * 4);
            mpCtx->IRARGBData = (uint8_t *)malloc(mpCtx->width * mpCtx->height * sizeof(uint8_t) * 4);
            mpCtx->tempOffset = 460;
            mpCtx->horizontalFov = 73;
            mpCtx->verticalFov = 53;
            mpCtx->coefTable = malloc(497 * mpCtx->width * sizeof(double));
            double* pCoefTable =(double*)mpCtx->coefTable;
            read_csv(497,mpCtx->width,coefPath,&pCoefTable);            
           *(pCoefTable + mpCtx->width * 248 + 0) = (*(pCoefTable + mpCtx->width * 248 + 0) - 1.05f)*100000;
           *(pCoefTable + mpCtx->width * 248 + 1) = (*(pCoefTable + mpCtx->width * 248 + 1) - 1.05f)*100000;
           *(pCoefTable + mpCtx->width * 248 + 2) = (*(pCoefTable + mpCtx->width * 248 + 2) - 1.05f)*100000;
           *(pCoefTable + mpCtx->width * 248 + 3) = (*(pCoefTable + mpCtx->width * 248 + 3) - 1.05f)*100000;
           *(pCoefTable + mpCtx->width * 248 + 4) = (*(pCoefTable + mpCtx->width * 248 + 4) - 1.05f)*100000;
            mpCtx->isCorrectOn = false;
        }
    }

    bool calculateDepth(void* pInRawData, uint16_t* pOutDepth);
    bool calculatePoints(uint16_t* pInDepth, float * pOutPoints);
    bool mipi12ToDepth(uint8_t* pInRawData, uint16_t* pOutData);
    bool bigEndianU16ToDepth(uint16_t* pInRawData, uint16_t* pOutData);
    bool littleEndianU16ToDepth(uint16_t* pInRawData, uint16_t* pOutData);
    bool depthCorrect(uint16_t* pInDepth);

protected:
    struct context* mpCtx = NULL;
    const int C_LIGHT_SPEED = 299792458; // m/s
    const double T0_LIGHT_PLUSE = 3.44E-8;
    const uint16_t MAXDEPTH = 4095;
    const float SMIN = 0;
    const float SMAX = 5000;
    const int CROPCELL = 4;
};
#endif //PROJECT_TOFCORE_H
