## Prerequisit
- linux env(ubuntu 14.04 + recommend)
- android sdk(latest recommend)
- android ndk(android-ndk-r14b recommend)

## Build
### export android ndk directory and android cmake directory
e.g.
~~~shell
export ANDROID_NDK=/home/user/gjx/env/android-ndk-r14b
export CMAKE_ROOT_DIR=/home/user/Android/Sdk/cmake/3.6.4111459
~~~
### run `build_for_android.sh` script
e.g.
~~~shell
./build_for_android.sh
~~~

## Result
~~~
.
├── build
│   ├── android_gradle_build.json
│   ├── CMakeCache.txt
│   ├── CMakeFiles
│   ├── cmake_install.cmake
│   ├── libOpnousTof.so  // build success
│   └── Makefile
├── build_for_android.sh
├── native
│   ├── CMakeLists.txt
│   ├── com_thundersoft_TSJniUtil.h
│   ├── inc
│   └── src
└── readme.md
~~~
