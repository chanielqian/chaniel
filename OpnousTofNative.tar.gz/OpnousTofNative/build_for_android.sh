#!/bin/bash
BUILD_DIR=build
CMAKE_BUILD_TYPE=Release
ANDROID_PLATFORM=android-21
ANDROID_ABI=armeabi-v7a
ANDROID_TOOL_CHAIN=$ANDROID_NDK/build/cmake/android.toolchain.cmake

export PATH=$CMAKE_ROOT_DIR/bin:$PATH
cmake --version

rm -rf $BUILD_DIR
mkdir $BUILD_DIR && cd $BUILD_DIR
cmake -DCMAKE_TOOLCHAIN_FILE=$ANDROID_TOOL_CHAIN                 \
      -DANDROID_NDK=$ANDROID_NDK                                 \
      -DCMAKE_BUILD_TYPE=$CMAKE_BUILD_TYPE                       \
      -DANDROID_ABI=$ANDROID_ABI                                 \
      -DANDROID_PLATFORM=$ANDROID_PLATFORM                       \
      ../native
cmake --build .
